package note.main;

public class ClasaException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public ClasaException (String mesaj) {
		super(mesaj);
	}

}
